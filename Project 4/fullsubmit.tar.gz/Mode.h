
enum class Mode { CAMPAIGN, MST, PATH };